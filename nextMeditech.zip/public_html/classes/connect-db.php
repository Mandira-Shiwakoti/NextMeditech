<?php
$host = 'sdb-88.hosting.stackcp.net';
$dbname = 'db_nextmedtech-35313135cc4d';
$username = 'nextmedtech'; // Default username for local dev
$password = '[ivG[F6CARG7';     // Default password (empty for XAMPP/MAMP unless changed)

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password);

    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

   // echo "✅ Database connection successful!";
} catch (PDOException $e) {
    echo "❌ Connection failed: " . $e->getMessage();
    exit;
}
?>
